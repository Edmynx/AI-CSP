# COSC 76, Fall 2020, PA-4, Edmund Aduse Poku

1) Unzip the provided zip file and put all the necessary modules in one project folder. The modules needed are csp.py, map\_coloring\_problem.py, circuit\_board\_problem.py, CSPSolution.py, search.py, heuristics.py, inferences.py, ac\_3.py, test\_circuit\_board.py, test\_map\_coloring. 

2) Open and execute the test\_map\_coloring file to run test cases for the Map Coloring Problem and test\_circuit\_board.py for the Circuit Board Layout Problem. You can tweak the test by passing in your own cases.

